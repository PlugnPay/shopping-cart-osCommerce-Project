<?php
/*
  $Id: plugnpay_ach_ss.php 1739 2009-01-03 00:52:16Z hpdl $

  osCommerce (Open Source Commerce)
  http://www.oscommerceproject.org

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_TEXT_TITLE', 'PlugnPay ACH SS');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_TEXT_PUBLIC_TITLE', 'ACH/eCheck (Processed by PlugnPay)');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.plugnpay.com" target="_blank" style="text-decoration: underline; font-weight: bold;">Visit PlugnPay.com Website</a>');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_TITLE', 'There has been an error processing your ACH payment');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_VERIFICATION', 'The ACH transaction could not be verified with this order. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_DECLINED', 'This ACH transaction has been declined. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_PROBLEM', 'There was a problem processing your ACH transaction. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_FRAUD', 'This ACH transaction has been rejected. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_GENERAL', 'Please try again and if problems persist, please try another payment method.');
?>
